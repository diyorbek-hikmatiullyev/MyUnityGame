using UnityEngine;

public class PlatformMovement : MonoBehaviour
{
    public float speed = 10f;   // Platforma tezligi
    public float limitX = 8f;   // Chap va o‘ng chegaralar (ekranga qarab sozlanadi)

    void Update()
    {
        float move = Input.GetAxis("Horizontal"); // Klaviatura: ← → tugmalar
        transform.Translate(Vector2.right * move * speed * Time.deltaTime);

        // Platformani chap va o‘ng tomondan chiqmaslik uchun cheklaymiz
        float clampedX = Mathf.Clamp(transform.position.x, -limitX, limitX);
        transform.position = new Vector3(clampedX, transform.position.y, transform.position.z);
    }
}
