using UnityEngine;

public class BallMovement : MonoBehaviour
{
    public float speed = 8f;      // To‘p tezligi
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.linearVelocity = new Vector2(speed, speed); // Boshlang‘ich yo‘nalish
    }

    void FixedUpdate()
    {
        // Har doim tezlikni bir xil saqlash
        rb.linearVelocity = rb.linearVelocity.normalized * speed;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        Vector2 normal = collision.contacts[0].normal;
        Vector2 newDirection = Vector2.Reflect(rb.linearVelocity, normal);

        // 🎯 Platformaga tegsa — yo‘nalishni yuqoriga o‘zgartiramiz
        if (collision.gameObject.CompareTag("Platform"))
        {
            // Platformaning markaziga nisbatan farqni hisoblaymiz
            float hitPoint = transform.position.x - collision.transform.position.x;
            newDirection = new Vector2(hitPoint, 1f).normalized;
        }

        // Tasodifiy kichik og‘ish qo‘shamiz (sakrash tabiiyroq bo‘lishi uchun)
        float randomAngle = Random.Range(-50f, 50f);
        newDirection = Quaternion.Euler(0, 0, randomAngle) * newDirection;

        rb.linearVelocity = newDirection.normalized * speed;
    }
}
